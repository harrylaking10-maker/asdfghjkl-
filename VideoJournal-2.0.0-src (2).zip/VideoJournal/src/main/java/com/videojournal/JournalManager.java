package com.videojournal;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Handles per-player YAML storage of video journals.
 * Each player gets a UUID-named file under plugins/VideoJournal/journals/.
 */
public class JournalManager {

    private final VideoJournal plugin;
    private final File dataFolder;

    public JournalManager(VideoJournal plugin) {
        this.plugin     = plugin;
        this.dataFolder = new File(plugin.getDataFolder(), "journals");
        if (!dataFolder.exists()) dataFolder.mkdirs();
    }

    // ── Public API ────────────────────────────────────────────────────────────

    public void storeJournal(Player player, Journal journal) {
        File file = playerFile(player.getUniqueId());
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(file);

        String root = "journals." + journal.getId();
        cfg.set(root + ".timestamp",  journal.getTimestamp());
        cfg.set(root + ".player",     journal.getPlayerName());
        cfg.set(root + ".recipients", journal.getRecipients());
        cfg.set(root + ".customName", journal.getCustomName());
        cfg.set(root + ".facingYaw",  journal.getRecordingFacingYaw());

        Location cam = journal.getCameraLocation();
        cfg.set(root + ".camera.world", cam.getWorld().getName());
        cfg.set(root + ".camera.x",     cam.getX());
        cfg.set(root + ".camera.y",     cam.getY());
        cfg.set(root + ".camera.z",     cam.getZ());

        List<String> frameData = new ArrayList<>();
        for (Journal.JournalFrame frame : journal.getFrames()) {
            frameData.add(encodeFrame(frame));
        }
        cfg.set(root + ".frames", frameData);

        try {
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Failed to save journal: " + e.getMessage());
        }
    }

    public List<Journal> getJournals(Player player) {
        List<Journal> result = new ArrayList<>();
        File file = playerFile(player.getUniqueId());
        if (!file.exists()) return result;

        FileConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        if (cfg.getConfigurationSection("journals") == null) return result;

        for (String id : cfg.getConfigurationSection("journals").getKeys(false)) {
            Journal j = deserialize(cfg, id);
            if (j != null) result.add(j);
        }
        return result;
    }

    public Journal getJournal(Player player, String journalId) {
        File file = playerFile(player.getUniqueId());
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        if (!cfg.contains("journals." + journalId)) return null;
        return deserialize(cfg, journalId);
    }

    /** Convenience alias used after naming / editing. */
    public void updateJournal(Player player, Journal journal) {
        storeJournal(player, journal);
    }

    public void deleteJournal(Player player, String journalId) {
        File file = playerFile(player.getUniqueId());
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        cfg.set("journals." + journalId, null);
        try {
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Failed to delete journal: " + e.getMessage());
        }
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private File playerFile(UUID uuid) {
        return new File(dataFolder, uuid + ".yml");
    }

    /**
     * Encodes a single frame to a compact pipe-delimited string.
     * 6 pipe-separated sections:
     *   capturedAt | playersInView(csv) | chatMsg | chatSender | movementData(;list) | equipmentData(;list)
     *
     * movementData entry:  name:x,y,z,yaw,pitch,vx,vy,vz,onGround,sneak,rx,ry,rz,sprint,swim
     * equipmentData entry: name:slot0~slot1~slot2~slot3~slot4~slot5
     *   each slot = Base64(ItemStack.serializeAsBytes()) or "-" for null/AIR
     */
    private String encodeFrame(Journal.JournalFrame f) {
        StringBuilder sb = new StringBuilder();
        sb.append(f.getCapturedAt()).append('|');
        sb.append(String.join(",", f.getPlayersInView())).append('|');
        sb.append(f.getChatMessage() != null ? f.getChatMessage() : "").append('|');
        sb.append(f.getChatSender()  != null ? f.getChatSender()  : "").append('|');

        // Section 4: movement
        StringBuilder loc = new StringBuilder();
        for (Map.Entry<String, Location> e : f.getPlayerLocations().entrySet()) {
            String   n   = e.getKey();
            Location l   = e.getValue();
            Vector vel   = f.getPlayerVelocity().getOrDefault(n, new Vector(0, 0, 0));
            Vector rel   = f.getPlayerRelativePositions().getOrDefault(n, new Vector(0, 0, 0));
            boolean og   = f.getPlayerOnGround().getOrDefault(n, true);
            boolean snk  = f.getPlayerSneaking().getOrDefault(n, false);
            boolean spr  = f.getPlayerSprinting().getOrDefault(n, false);
            boolean swm  = f.getPlayerSwimming().getOrDefault(n, false);
            loc.append(n).append(':')
               .append(l.getX()).append(',').append(l.getY()).append(',').append(l.getZ()).append(',')
               .append(l.getYaw()).append(',').append(l.getPitch()).append(',')
               .append(vel.getX()).append(',').append(vel.getY()).append(',').append(vel.getZ()).append(',')
               .append(og).append(',').append(snk).append(',')
               .append(rel.getX()).append(',').append(rel.getY()).append(',').append(rel.getZ()).append(',')
               .append(spr).append(',').append(swm).append(';');
        }
        if (loc.length() > 0) loc.setLength(loc.length() - 1);
        sb.append(loc).append('|');

        // Section 5: equipment  (helmet,chest,legs,boots,mainhand,offhand) per player
        // Serialise each ItemStack via Bukkit's own YAML serializer → Base64 so it
        // fits cleanly in our pipe-delimited single-line frame string.
        StringBuilder eq = new StringBuilder();
        for (Map.Entry<String, org.bukkit.inventory.ItemStack[]> e : f.getPlayerEquipment().entrySet()) {
            eq.append(e.getKey()).append(':');
            org.bukkit.inventory.ItemStack[] gear = e.getValue();
            for (int i = 0; i < 6; i++) {
                if (i > 0) eq.append('~');
                org.bukkit.inventory.ItemStack item = (gear != null && i < gear.length) ? gear[i] : null;
                if (item == null || item.getType() == org.bukkit.Material.AIR) {
                    eq.append('-');
                } else {
                    try {
                        org.bukkit.configuration.file.YamlConfiguration tmp =
                            new org.bukkit.configuration.file.YamlConfiguration();
                        tmp.set("i", item);
                        String yaml = tmp.saveToString();
                        eq.append(java.util.Base64.getEncoder().encodeToString(yaml.getBytes(java.nio.charset.StandardCharsets.UTF_8)));
                    } catch (Exception ex) {
                        eq.append('-');
                    }
                }
            }
            eq.append(';');
        }
        if (eq.length() > 0) eq.setLength(eq.length() - 1);
        sb.append(eq);
        return sb.toString();
    }

    /** Deserialises a journal entry from YAML config. */
    private Journal deserialize(FileConfiguration cfg, String id) {
        String root = "journals." + id;

        String timestamp  = cfg.getString(root + ".timestamp");
        String playerName = cfg.getString(root + ".player");
        List<String> recipients = cfg.getStringList(root + ".recipients");
        String customName = cfg.getString(root + ".customName");
        float facingYaw   = (float) cfg.getDouble(root + ".facingYaw", 0.0);
        String worldName  = cfg.getString(root + ".camera.world");

        if (worldName == null) return null;

        Location cameraLoc = new Location(
            Bukkit.getWorld(worldName),
            cfg.getDouble(root + ".camera.x"),
            cfg.getDouble(root + ".camera.y"),
            cfg.getDouble(root + ".camera.z")
        );

        List<Journal.JournalFrame> frames = new ArrayList<>();
        for (String raw : cfg.getStringList(root + ".frames")) {
            Journal.JournalFrame frame = decodeFrame(raw, cameraLoc);
            if (frame != null) frames.add(frame);
        }

        return new Journal(id, frames, playerName, timestamp, recipients, cameraLoc, customName, facingYaw);
    }

    /** Decodes a frame string back into a JournalFrame. */
    private Journal.JournalFrame decodeFrame(String raw, Location cameraLoc) {
        // Split into up to 6 sections: capturedAt|players|chatMsg|chatSender|movementData|equipmentData
        String[] parts = raw.split("\\|", -1);
        if (parts.length < 4) return null;

        List<String> playersInView = new ArrayList<>();
        if (!parts[1].isEmpty()) {
            playersInView.addAll(Arrays.asList(parts[1].split(",")));
        }

        String chatMsg    = parts[2].isEmpty() ? null : parts[2];
        String chatSender = parts[3].isEmpty() ? null : parts[3];

        Map<String, Location>                 locs   = new HashMap<>();
        Map<String, Float>                    yaws   = new HashMap<>();
        Map<String, Float>                    pitches= new HashMap<>();
        Map<String, Boolean>                  ground = new HashMap<>();
        Map<String, Vector>                   vels   = new HashMap<>();
        Map<String, Boolean>                  sneak  = new HashMap<>();
        Map<String, Boolean>                  sprint = new HashMap<>();
        Map<String, Boolean>                  swim   = new HashMap<>();
        Map<String, Vector>                   rels   = new HashMap<>();
        Map<String, org.bukkit.inventory.ItemStack[]> equipment = new HashMap<>();

        // Section 4: movement data
        if (parts.length > 4 && !parts[4].isEmpty()) {
            for (String entry : parts[4].split(";")) {
                String[] kv = entry.split(":", 2);
                if (kv.length != 2) continue;
                String name = kv[0];
                String[] c  = kv[1].split(",");
                if (c.length < 5) continue;

                double x  = Double.parseDouble(c[0]);
                double y  = Double.parseDouble(c[1]);
                double z  = Double.parseDouble(c[2]);
                float  yw = Float.parseFloat(c[3]);
                float  pt = Float.parseFloat(c[4]);

                locs.put(name, new Location(cameraLoc.getWorld(), x, y, z, yw, pt));
                yaws.put(name, yw);
                pitches.put(name, pt);

                if (c.length >= 9) {
                    vels.put(name, new Vector(Double.parseDouble(c[5]), Double.parseDouble(c[6]), Double.parseDouble(c[7])));
                    ground.put(name, Boolean.parseBoolean(c[8]));
                } else {
                    vels.put(name, new Vector(0, 0, 0));
                    ground.put(name, true);
                }
                if (c.length >= 10) sneak.put(name, Boolean.parseBoolean(c[9]));   else sneak.put(name, false);
                if (c.length >= 13) rels.put(name, new Vector(Double.parseDouble(c[10]), Double.parseDouble(c[11]), Double.parseDouble(c[12]))); else rels.put(name, new Vector(0,0,0));
                if (c.length >= 14) sprint.put(name, Boolean.parseBoolean(c[13])); else sprint.put(name, false);
                if (c.length >= 15) swim.put(name, Boolean.parseBoolean(c[14]));   else swim.put(name, false);
            }
        }

        // Section 5: equipment data (absent in old saves — gracefully skipped)
        if (parts.length > 5 && !parts[5].isEmpty()) {
            for (String entry : parts[5].split(";")) {
                String[] kv = entry.split(":", 2);
                if (kv.length != 2) continue;
                String name    = kv[0];
                String[] slots = kv[1].split("~", -1);
                org.bukkit.inventory.ItemStack[] gear = new org.bukkit.inventory.ItemStack[6];
                for (int i = 0; i < 6 && i < slots.length; i++) {
                    if (slots[i].equals("-")) {
                        gear[i] = null;
                    } else {
                        try {
                            String yaml = new String(
                                java.util.Base64.getDecoder().decode(slots[i]),
                                java.nio.charset.StandardCharsets.UTF_8);
                            org.bukkit.configuration.file.YamlConfiguration tmp =
                                new org.bukkit.configuration.file.YamlConfiguration();
                            tmp.loadFromString(yaml);
                            gear[i] = tmp.getItemStack("i");
                        } catch (Exception ex) {
                            gear[i] = null;
                        }
                    }
                }
                equipment.put(name, gear);
            }
        }

        return new Journal.JournalFrame(playersInView, chatMsg, chatSender,
                locs, yaws, pitches, ground, vels, sneak, sprint, swim, rels, equipment);
    }
}
