package com.videojournal;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class EndJournalCommand implements CommandExecutor {

    private final VideoJournal plugin;

    public EndJournalCommand(VideoJournal plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command can only be used by players!");
            return true;
        }
        if (!plugin.isJournalsEnabled() && !player.isOp()) {
            player.sendMessage(ChatColor.RED + "✗ Video Journals are currently disabled.");
            return true;
        }
        if (plugin.getRecordListener().isRecording(player)) {
            plugin.getRecordListener().finishRecording(player);
        } else if (plugin.getJournalGUI().isViewing(player)) {
            plugin.getJournalGUI().stopViewing(player);
            player.sendMessage(ChatColor.GREEN + "✓ Closed journal.");
        } else {
            player.sendMessage(ChatColor.RED + "You are not currently recording or watching a journal!");
        }
        return true;
    }
}
