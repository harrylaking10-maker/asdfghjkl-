package com.videojournal;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class ToggleJournalsCommand implements CommandExecutor {

    private final VideoJournal plugin;
    private final boolean      enable;

    public ToggleJournalsCommand(VideoJournal plugin, boolean enable) {
        this.plugin = plugin;
        this.enable = enable;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.isOp()) {
            sender.sendMessage(ChatColor.RED + "✗ You must be an operator to use this command!");
            return true;
        }

        if (enable) {
            if (plugin.isJournalsEnabled()) {
                sender.sendMessage(ChatColor.YELLOW + "⚠ Video Journals are already enabled.");
                return true;
            }
            plugin.setJournalsEnabled(true);
            sender.sendMessage(ChatColor.GREEN + "✓ Video Journals " + ChatColor.BOLD + "enabled" + ChatColor.GREEN + ".");
            plugin.getServer().broadcastMessage(ChatColor.GREEN + "[VideoJournal] " + ChatColor.WHITE
                + "Video Journals have been enabled by " + ChatColor.YELLOW + sender.getName() + ChatColor.WHITE + ".");
        } else {
            if (!plugin.isJournalsEnabled()) {
                sender.sendMessage(ChatColor.YELLOW + "⚠ Video Journals are already disabled.");
                return true;
            }
            plugin.getRecordListener().cancelRecording();
            plugin.getJournalGUI().stopAllPlaybacks();
            plugin.setJournalsEnabled(false);
            sender.sendMessage(ChatColor.RED + "✗ Video Journals " + ChatColor.BOLD + "disabled" + ChatColor.RED + ".");
            plugin.getServer().broadcastMessage(ChatColor.RED + "[VideoJournal] " + ChatColor.WHITE
                + "Video Journals have been disabled by " + ChatColor.YELLOW + sender.getName() + ChatColor.WHITE + ".");
        }
        return true;
    }
}
