package com.videojournal;

import org.bukkit.Location;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Represents a recorded video journal: a sequence of frames capturing
 * player positions, equipment, motion state, and chat, anchored to a
 * camera (dispenser) location.
 */
public class Journal {

    private final String id;
    private final String playerName;
    private final String timestamp;
    private final Location cameraLocation;
    private final List<JournalFrame> frames;
    private final List<String> recipients;
    private String customName;
    private float recordingFacingYaw;
    private final List<String[]> chatLog = new ArrayList<>(); // [senderName, message]

    /** New recording constructor. */
    public Journal(String playerName, Location cameraLocation) {
        this.id             = UUID.randomUUID().toString();
        this.playerName     = playerName;
        this.timestamp      = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        this.cameraLocation = cameraLocation;
        this.frames         = new ArrayList<>();
        this.recipients     = new ArrayList<>();
        this.customName     = null;
        this.recordingFacingYaw = 0f;
    }

    /** Deserialization constructor (with yaw). */
    public Journal(String id, List<JournalFrame> frames, String playerName, String timestamp,
                   List<String> recipients, Location cameraLocation, String customName,
                   float recordingFacingYaw) {
        this.id                  = id;
        this.frames              = frames;
        this.playerName          = playerName;
        this.timestamp           = timestamp;
        this.recipients          = recipients != null ? recipients : new ArrayList<>();
        this.cameraLocation      = cameraLocation;
        this.customName          = customName;
        this.recordingFacingYaw  = recordingFacingYaw;
    }

    /** Deserialization constructor (legacy, no yaw). */
    public Journal(String id, List<JournalFrame> frames, String playerName, String timestamp,
                   List<String> recipients, Location cameraLocation, String customName) {
        this(id, frames, playerName, timestamp, recipients, cameraLocation, customName, 0f);
    }

    // ── Getters ──────────────────────────────────────────────────────────────

    public String         getId()                   { return id; }
    public String         getPlayerName()           { return playerName; }
    public String         getTimestamp()            { return timestamp; }
    public Location       getCameraLocation()       { return cameraLocation; }
    public List<JournalFrame> getFrames()           { return frames; }
    public List<String>   getRecipients()           { return recipients; }
    public String         getCustomName()           { return customName; }
    public float          getRecordingFacingYaw()   { return recordingFacingYaw; }
    public List<String[]> getChatLog()              { return chatLog; }

    // ── Mutators ─────────────────────────────────────────────────────────────

    public void setCustomName(String name)          { this.customName = name; }
    public void setRecordingFacingYaw(float yaw)    { this.recordingFacingYaw = yaw; }

    public void addFrame(JournalFrame frame)        { frames.add(frame); }

    public void addRecipient(String uuid) {
        if (!recipients.contains(uuid)) recipients.add(uuid);
    }

    public void addChatLog(String sender, String message) {
        chatLog.add(new String[]{sender, message});
    }

    // ── Inner class: JournalFrame ─────────────────────────────────────────────

    public static class JournalFrame {

        private final long capturedAt = System.currentTimeMillis();

        private final List<String>        playersInView;
        private final String              chatMessage;
        private final String              chatSender;

        private final Map<String, Location>   playerLocations;
        private final Map<String, Float>      playerYaw;
        private final Map<String, Float>      playerPitch;
        private final Map<String, Boolean>    playerOnGround;
        private final Map<String, Vector>     playerVelocity;
        private final Map<String, Boolean>    playerSneaking;
        private final Map<String, Boolean>    playerSprinting;
        private final Map<String, Boolean>    playerSwimming;
        private final Map<String, Vector>     playerRelativePositions;
        // Index: 0=helmet 1=chest 2=legs 3=boots 4=mainhand 5=offhand
        private final Map<String, ItemStack[]> playerEquipment;

        public JournalFrame(List<String> playersInView, String chatMessage, String chatSender,
                            Map<String, Location> playerLocations,
                            Map<String, Float> playerYaw, Map<String, Float> playerPitch,
                            Map<String, Boolean> playerOnGround,
                            Map<String, Vector> playerVelocity,
                            Map<String, Boolean> playerSneaking,
                            Map<String, Boolean> playerSprinting,
                            Map<String, Boolean> playerSwimming,
                            Map<String, Vector> playerRelativePositions,
                            Map<String, ItemStack[]> playerEquipment) {
            this.playersInView           = playersInView;
            this.chatMessage             = chatMessage;
            this.chatSender              = chatSender;
            this.playerLocations         = playerLocations;
            this.playerYaw               = playerYaw;
            this.playerPitch             = playerPitch;
            this.playerOnGround          = playerOnGround;
            this.playerVelocity          = playerVelocity;
            this.playerSneaking          = playerSneaking;
            this.playerSprinting         = playerSprinting;
            this.playerSwimming          = playerSwimming;
            this.playerRelativePositions = playerRelativePositions;
            this.playerEquipment         = playerEquipment;
        }

        /** Convenience constructor without equipment (defaults to empty map). */
        public JournalFrame(List<String> playersInView, String chatMessage, String chatSender,
                            Map<String, Location> playerLocations,
                            Map<String, Float> playerYaw, Map<String, Float> playerPitch,
                            Map<String, Boolean> playerOnGround,
                            Map<String, Vector> playerVelocity,
                            Map<String, Boolean> playerSneaking,
                            Map<String, Boolean> playerSprinting,
                            Map<String, Boolean> playerSwimming,
                            Map<String, Vector> playerRelativePositions) {
            this(playersInView, chatMessage, chatSender, playerLocations,
                    playerYaw, playerPitch, playerOnGround, playerVelocity,
                    playerSneaking, playerSprinting, playerSwimming,
                    playerRelativePositions, new HashMap<>());
        }

        public long                     getCapturedAt()             { return capturedAt; }
        public List<String>             getPlayersInView()          { return playersInView; }
        public String                   getChatMessage()            { return chatMessage; }
        public String                   getChatSender()             { return chatSender; }
        public Map<String, Location>    getPlayerLocations()        { return playerLocations; }
        public Map<String, Float>       getPlayerYaw()              { return playerYaw; }
        public Map<String, Float>       getPlayerPitch()            { return playerPitch; }
        public Map<String, Boolean>     getPlayerOnGround()         { return playerOnGround; }
        public Map<String, Vector>      getPlayerVelocity()         { return playerVelocity; }
        public Map<String, Boolean>     getPlayerSneaking()         { return playerSneaking; }
        public Map<String, Boolean>     getPlayerSprinting()        { return playerSprinting; }
        public Map<String, Boolean>     getPlayerSwimming()         { return playerSwimming; }
        public Map<String, Vector>      getPlayerRelativePositions(){ return playerRelativePositions; }
        public Map<String, ItemStack[]> getPlayerEquipment()        { return playerEquipment; }
    }
}
