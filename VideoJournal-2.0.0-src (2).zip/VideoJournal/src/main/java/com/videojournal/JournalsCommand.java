package com.videojournal;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class JournalsCommand implements CommandExecutor {

    private final VideoJournal plugin;

    public JournalsCommand(VideoJournal plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command can only be used by players!");
            return true;
        }
        if (!plugin.isJournalsEnabled()) {
            player.sendMessage(ChatColor.RED + "✗ Video Journals are currently disabled.");
            return true;
        }
        if (!player.hasPermission("permission.videojournal")) {
            player.sendMessage(ChatColor.RED + "✗ You do not have permission to use Video Journals!");
            return true;
        }
        plugin.getJournalGUI().openJournalList(player);
        return true;
    }
}
