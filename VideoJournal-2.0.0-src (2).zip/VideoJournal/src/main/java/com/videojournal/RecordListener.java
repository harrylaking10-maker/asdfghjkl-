package com.videojournal;

import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.Directional;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * Handles all recording-side logic: starting / stopping a recording,
 * per-tick frame capture, actionbar updates, participant consent prompts,
 * chat log capture, and the post-recording naming flow.
 */
public class RecordListener implements Listener {

    private static final double RECORDING_RADIUS = 10.0;
    private static final int    TICKS_PER_SECOND  = 20;

    private final VideoJournal plugin;

    // Active recording state
    private Journal  currentRecording;
    private Player   recordingPlayer;
    private BukkitTask recordingTask;
    private BukkitTask actionbarTask;

    private final Set<UUID>            participatingPlayers   = new HashSet<>();
    private final Set<UUID>            askedPlayers           = new HashSet<>();
    private final Map<String, Vector>  playerRelativePositions= new HashMap<>();
    // Awaiting chat input to name a journal: playerUUID -> journalId
    private final Map<UUID, String>    awaitingJournalName    = new HashMap<>();

    public RecordListener(VideoJournal plugin) {
        this.plugin = plugin;
    }

    // ── Public state queries ──────────────────────────────────────────────────

    public boolean isRecording()               { return currentRecording != null; }
    public boolean isRecording(Player p)       { return recordingPlayer != null && recordingPlayer.equals(p); }

    public boolean isRecordingAt(Location loc) {
        if (currentRecording == null) return false;
        Location cam = currentRecording.getCameraLocation();
        return cam.getWorld().getName().equals(loc.getWorld().getName())
            && cam.getBlockX() == loc.getBlockX()
            && cam.getBlockY() == loc.getBlockY()
            && cam.getBlockZ() == loc.getBlockZ();
    }

    public boolean isAwaitingName(UUID id) { return awaitingJournalName.containsKey(id); }
    public boolean hasBeenAsked(UUID id)   { return askedPlayers.contains(id); }

    public Set<UUID>           getParticipatingPlayers()    { return participatingPlayers; }
    public Map<String, Vector> getPlayerRelativePositions() { return playerRelativePositions; }

    public void addParticipatingPlayer(UUID id) { participatingPlayers.add(id); }
    public void markAsAsked(UUID id)            { askedPlayers.add(id); }

    // ── Post-recording name capture ───────────────────────────────────────────

    public void setJournalName(UUID playerId, String name) {
        String journalId = awaitingJournalName.remove(playerId);
        if (journalId == null) return;

        Player player = Bukkit.getPlayer(playerId);
        if (player == null) return;

        Journal journal = plugin.getJournalManager().getJournal(player, journalId);
        if (journal == null) return;

        journal.setCustomName(name);
        plugin.getJournalManager().updateJournal(player, journal);

        player.sendMessage("");
        player.sendMessage(ChatColor.GREEN + "✓ Journal named: " + ChatColor.LIGHT_PURPLE + name);

        Bukkit.getScheduler().runTask(plugin, () ->
            plugin.getJournalGUI().openJournalOptions(player, journalId));
    }

    // ── Start / stop ──────────────────────────────────────────────────────────

    public void startRecording(Player player, Location dispenserLocation) {
        if (plugin.getJournalGUI().isAnyoneViewingAt(dispenserLocation)) {
            player.sendMessage(ChatColor.RED + "✗ Cannot record – someone is currently watching a journal here!");
            return;
        }

        currentRecording = new Journal(player.getName(), dispenserLocation);
        recordingPlayer  = player;
        participatingPlayers.clear();
        askedPlayers.clear();
        playerRelativePositions.clear();
        participatingPlayers.add(player.getUniqueId());
        askedPlayers.add(player.getUniqueId());

        float facingYaw = blockFaceToYaw(getDispenserFacing(dispenserLocation));
        currentRecording.setRecordingFacingYaw(facingYaw);

        player.sendMessage(ChatColor.GREEN + "● Camera recording started!");
        player.sendMessage(ChatColor.GRAY + "Recording from Video Journal at "
            + dispenserLocation.getBlockX() + ", "
            + dispenserLocation.getBlockY() + ", "
            + dispenserLocation.getBlockZ());
        player.sendMessage(ChatColor.GRAY + "Use /endjournal to stop recording.");
        player.sendMessage(ChatColor.STRIKETHROUGH + "" + ChatColor.DARK_GRAY + "━━━━━━━━ RECORDING ━━━━━━━━");

        startFrameCapture();
        startActionbar();
    }

    public String finishRecording(Player player) {
        if (currentRecording == null || !player.equals(recordingPlayer)) return null;

        if (currentRecording.getFrames().isEmpty()) {
            player.sendMessage(ChatColor.STRIKETHROUGH + "" + ChatColor.DARK_GRAY + "━━━━━━━━━━━━━━━━━━━━━━━━");
            player.sendMessage(ChatColor.RED + "✗ No frames recorded. Recording cancelled.");
            cancelRecording();
            return null;
        }

        Player savedPlayer   = recordingPlayer;
        Journal savedJournal = currentRecording;
        plugin.getJournalManager().storeJournal(savedPlayer, savedJournal);

        // Prompt recorder to name the journal via chat
        plugin.getJournalGUI().setAwaitingJournalName(savedPlayer.getUniqueId(), savedJournal.getId());
        savedPlayer.sendMessage("");
        savedPlayer.sendMessage(ChatColor.GOLD + "━━━━━━━━ Name Your Journal ━━━━━━━━");
        savedPlayer.sendMessage(ChatColor.YELLOW + "Type a name for this video journal in chat:");
        savedPlayer.sendMessage(ChatColor.GRAY + "(Example: My First Adventure)");
        savedPlayer.sendMessage(ChatColor.GOLD + "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

        // Notify other participants
        String sep = ChatColor.STRIKETHROUGH + "" + ChatColor.DARK_GRAY + "━━━━━━━━━━━━━━━━━━━━━━━━";
        int durationSecs = savedJournal.getFrames().size() / TICKS_PER_SECOND;
        for (UUID pid : new HashSet<>(participatingPlayers)) {
            if (pid.equals(savedPlayer.getUniqueId())) continue;
            Player p = Bukkit.getPlayer(pid);
            if (p == null || !p.isOnline()) continue;
            p.sendMessage(sep);
            p.sendMessage(ChatColor.RED + "◼ Recording ended by " + ChatColor.YELLOW + savedPlayer.getName());
            p.sendMessage(ChatColor.GRAY + "Duration: " + ChatColor.WHITE + durationSecs + "s");
            sendChatRecap(p, savedJournal);
        }
        sendChatRecap(savedPlayer, savedJournal);

        String journalId = savedJournal.getId();
        cancelRecording();
        return journalId;
    }

    public void cancelRecording() {
        if (recordingTask != null) { recordingTask.cancel(); recordingTask = null; }
        if (actionbarTask != null) { actionbarTask.cancel(); actionbarTask = null; }
        if (recordingPlayer != null)
            recordingPlayer.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(""));
        currentRecording = null;
        recordingPlayer  = null;
        participatingPlayers.clear();
        askedPlayers.clear();
        playerRelativePositions.clear();
    }

    // ── Frame capture internals ───────────────────────────────────────────────

    private void startFrameCapture() {
        recordingTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (currentRecording != null) captureFrame();
        }, 0L, 1L);
    }

    private void captureFrame() {
        Location camera = currentRecording.getCameraLocation();

        // Invite nearby unanswered players
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!askedPlayers.contains(p.getUniqueId())
                    && p.getLocation().getWorld().equals(camera.getWorld())
                    && p.getLocation().distance(camera) <= RECORDING_RADIUS) {
                askedPlayers.add(p.getUniqueId());
                plugin.getJournalGUI().openRecordingJoinPrompt(p, camera);
            }
        }

        List<String>              inView    = getPlayersInRadius(camera);
        Map<String, Location>     locs      = new HashMap<>();
        Map<String, Float>        yaws      = new HashMap<>();
        Map<String, Float>        pitches   = new HashMap<>();
        Map<String, Boolean>      ground    = new HashMap<>();
        Map<String, Vector>       vels      = new HashMap<>();
        Map<String, Boolean>      sneak     = new HashMap<>();
        Map<String, Boolean>      sprint    = new HashMap<>();
        Map<String, Boolean>      swim      = new HashMap<>();
        Map<String, Vector>       rels      = new HashMap<>();
        Map<String, ItemStack[]>  equipment = new HashMap<>();

        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!inView.contains(p.getName())) continue;
            if (!participatingPlayers.contains(p.getUniqueId())) continue;

            Location loc = p.getLocation();
            locs.put(p.getName(),     loc.clone());
            yaws.put(p.getName(),     loc.getYaw());
            pitches.put(p.getName(),  loc.getPitch());
            ground.put(p.getName(),   p.isOnGround());
            vels.put(p.getName(),     p.getVelocity().clone());
            sneak.put(p.getName(),    p.isSneaking());
            sprint.put(p.getName(),   p.isSprinting());
            swim.put(p.getName(),     p.isSwimming());
            // Record relative to block centre (camera corner + 0.5 on X/Z) so that
            // playback can add the rotated vector straight to the block corner Location
            // and land at the correct decimal position.
            Vector cameraBlockCentre = new Vector(
                camera.getBlockX() + 0.5,
                camera.getBlockY(),
                camera.getBlockZ() + 0.5);
            Vector rel = loc.toVector().subtract(cameraBlockCentre);
            rels.put(p.getName(), rel);
            playerRelativePositions.put(p.getName(), rel);
            equipment.put(p.getName(), captureEquipment(p));
        }

        currentRecording.addFrame(new Journal.JournalFrame(
            inView, null, null,
            locs, yaws, pitches, ground, vels, sneak, sprint, swim, rels, equipment));
    }

    private List<String> getPlayersInRadius(Location camera) {
        List<String> result = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            Location loc = p.getLocation();
            if (loc.getWorld().equals(camera.getWorld()) && loc.distance(camera) <= RECORDING_RADIUS)
                result.add(p.getName());
        }
        return result;
    }

    private void startActionbar() {
        actionbarTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (currentRecording == null || recordingPlayer == null) return;
            int secs = currentRecording.getFrames().size() / TICKS_PER_SECOND;
            String msg = ChatColor.RED + "● " + ChatColor.YELLOW + "RECORDING "
                       + ChatColor.WHITE + "[" + secs + "s] "
                       + ChatColor.GRAY + "(/endjournal to stop)";
            recordingPlayer.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(msg));
        }, 0L, 20L);
    }

    // ── Chat event ────────────────────────────────────────────────────────────

    @EventHandler
    public void onChat(AsyncPlayerChatEvent event) {
        Player player   = event.getPlayer();
        UUID   playerId = player.getUniqueId();

        // Intercept journal naming input
        if (awaitingJournalName.containsKey(playerId)) {
            event.setCancelled(true);
            String name = event.getMessage();
            Bukkit.getScheduler().runTask(plugin, () -> setJournalName(playerId, name));
            return;
        }

        // Record chat frames during active recording
        if (currentRecording != null) {
            String playerName = player.getName();
            String message    = event.getMessage();
            List<String> inView = getPlayersInRadius(currentRecording.getCameraLocation());

            if (inView.contains(playerName) && participatingPlayers.contains(playerId)) {
                // Restrict chat visibility to participants
                event.getRecipients().removeIf(r -> !participatingPlayers.contains(r.getUniqueId()));
            }

            Bukkit.getScheduler().runTask(plugin, () -> {
                if (currentRecording == null) return;
                if (!inView.contains(playerName)) return;
                if (!participatingPlayers.contains(playerId)) return;

                Location cam = currentRecording.getCameraLocation();
                Map<String, Location>    locs   = new HashMap<>();
                Map<String, Float>       yaws   = new HashMap<>();
                Map<String, Float>       pitches= new HashMap<>();
                Map<String, Boolean>     ground = new HashMap<>();
                Map<String, Vector>      vels   = new HashMap<>();
                Map<String, Boolean>     sneak  = new HashMap<>();
                Map<String, Boolean>     sprint = new HashMap<>();
                Map<String, Boolean>     swim   = new HashMap<>();
                Map<String, Vector>      rels   = new HashMap<>();
                Map<String, ItemStack[]> equip  = new HashMap<>();

                for (Player p : Bukkit.getOnlinePlayers()) {
                    if (!inView.contains(p.getName())) continue;
                    Location loc = p.getLocation();
                    locs.put(p.getName(),    loc.clone());
                    yaws.put(p.getName(),    loc.getYaw());
                    pitches.put(p.getName(), loc.getPitch());
                    ground.put(p.getName(),  p.isOnGround());
                    vels.put(p.getName(),    p.getVelocity().clone());
                    sneak.put(p.getName(),   p.isSneaking());
                    sprint.put(p.getName(),  p.isSprinting());
                    swim.put(p.getName(),    p.isSwimming());
                    Vector camCentre = new Vector(cam.getBlockX() + 0.5, cam.getBlockY(), cam.getBlockZ() + 0.5);
                    rels.put(p.getName(),    loc.toVector().subtract(camCentre));
                    equip.put(p.getName(),   captureEquipment(p));
                }

                currentRecording.addChatLog(playerName, message);
                currentRecording.addFrame(new Journal.JournalFrame(
                    inView, message, playerName,
                    locs, yaws, pitches, ground, vels, sneak, sprint, swim, rels, equip));
            });
        }
    }

    // ── Utilities ─────────────────────────────────────────────────────────────

    /** Captures helmet/chest/legs/boots/mainhand/offhand for a player. */
    public static ItemStack[] captureEquipment(Player p) {
        var inv = p.getInventory();
        return new ItemStack[]{
            inv.getHelmet()     != null ? inv.getHelmet().clone()     : null,
            inv.getChestplate() != null ? inv.getChestplate().clone() : null,
            inv.getLeggings()   != null ? inv.getLeggings().clone()   : null,
            inv.getBoots()      != null ? inv.getBoots().clone()      : null,
            inv.getItemInMainHand().getType() != org.bukkit.Material.AIR
                ? inv.getItemInMainHand().clone() : null,
            inv.getItemInOffHand().getType()  != org.bukkit.Material.AIR
                ? inv.getItemInOffHand().clone()  : null,
        };
    }

    /** Sends a recap of chat messages logged during a recording. */
    public void sendChatRecap(Player player, Journal journal) {
        List<String[]> log = journal.getChatLog();
        if (log.isEmpty()) return;
        player.sendMessage("");
        player.sendMessage(ChatColor.DARK_PURPLE + "━━━━━━━━ Chat During Recording ━━━━━━━━");
        for (String[] entry : log) {
            player.sendMessage(
                ChatColor.GRAY + "[" + ChatColor.LIGHT_PURPLE + "Journal" + ChatColor.GRAY + "] "
                + ChatColor.YELLOW + entry[0] + ChatColor.GRAY + ": "
                + ChatColor.WHITE + entry[1]);
        }
        player.sendMessage(ChatColor.DARK_PURPLE + "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    }

    private BlockFace getDispenserFacing(Location loc) {
        try {
            return ((Directional) loc.getBlock().getBlockData()).getFacing();
        } catch (Exception e) {
            return BlockFace.NORTH;
        }
    }

    public static float blockFaceToYaw(BlockFace face) {
        return switch (face) {
            case SOUTH -> 0f;
            case WEST  -> 90f;
            case NORTH -> 180f;
            case EAST  -> 270f;
            default    -> 0f;
        };
    }
}
