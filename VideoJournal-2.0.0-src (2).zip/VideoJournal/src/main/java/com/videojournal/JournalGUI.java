package com.videojournal;

import net.citizensnpcs.api.CitizensAPI;
import net.citizensnpcs.api.npc.NPC;
import net.citizensnpcs.api.npc.NPCRegistry;
import net.citizensnpcs.trait.SkinTrait;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * All GUI menus, playback sessions, viewer actionbars, and inventory events.
 */
public class JournalGUI implements Listener {

    // ── Menu titles ───────────────────────────────────────────────────────────
    private static final String TITLE_LIST           = ChatColor.DARK_PURPLE + "My Video Journals";
    private static final String TITLE_OPTIONS        = ChatColor.DARK_PURPLE + "Video Journal Options";
    private static final String TITLE_SEND           = ChatColor.DARK_PURPLE + "Send to Player";
    private static final String TITLE_SELECT_WATCH   = ChatColor.DARK_PURPLE + "Select Journal to Watch";
    private static final String TITLE_RECORD_WATCH   = ChatColor.DARK_PURPLE + "Record or Watch?";
    private static final String TITLE_CONFIRM_RECORD = ChatColor.DARK_GRAY   + "Start Recording?";
    private static final String TITLE_JOIN_RECORD    = ChatColor.DARK_PURPLE + "Join Recording?";
    private static final String TITLE_WATCH_PROMPT   = ChatColor.DARK_PURPLE + "Watch Video Journal?";
    private static final String TITLE_PLAY_CONFIRM   = ChatColor.DARK_PURPLE + "Play Video Journal?";

    private static final double NEARBY_PROMPT_RADIUS  = 13.0;
    private static final int    MAX_PLAYBACK_VIEWERS   = 10;

    private final VideoJournal plugin;

    // State maps
    private final Map<UUID,   String>          viewingJournal        = new HashMap<>();
    private final Map<String, Journal>         pendingJournals       = new HashMap<>();
    private final Map<UUID,   Location>        pendingRecordLocations= new HashMap<>();
    private final Map<UUID,   BukkitTask>      viewingActionbarTasks = new HashMap<>();
    private final Map<String, PlaybackSession> activePlaybacks       = new HashMap<>();
    // Awaiting chat to name a journal: playerId -> journalId
    private final Map<UUID,   String>          awaitingJournalName   = new HashMap<>();

    public JournalGUI(VideoJournal plugin) { this.plugin = plugin; }

    // ── External setters used by RecordListener ───────────────────────────────

    public void setAwaitingJournalName(UUID playerId, String journalId) {
        awaitingJournalName.put(playerId, journalId);
    }

    public boolean hasPendingJournal(String key)    { return pendingJournals.containsKey(key); }
    public Journal getPendingJournal(String key)    { return pendingJournals.get(key); }

    public boolean isViewing(Player p) {
        String state = viewingJournal.get(p.getUniqueId());
        return state != null && state.startsWith("VIEWING_");
    }

    // ── Location helpers ──────────────────────────────────────────────────────

    private String locationKey(Location loc) {
        return loc.getWorld().getName() + "_" + loc.getBlockX() + "_" + loc.getBlockY() + "_" + loc.getBlockZ();
    }

    private boolean locationMatches(Location a, Location b) {
        return a.getWorld().getName().equals(b.getWorld().getName())
            && a.getBlockX() == b.getBlockX()
            && a.getBlockY() == b.getBlockY()
            && a.getBlockZ() == b.getBlockZ();
    }

    // ── Rotation math ─────────────────────────────────────────────────────────

    /**
     * Rotates a relative XZ offset vector by angleDeg degrees CCW in MC world space.
     * MC axes: X=East, Z=South.
     * CCW rotation matrix: x' = x·cos - z·sin,  z' = x·sin + z·cos
     *
     * The pivot is always (0,0) — i.e. the camera block corner — because relative
     * positions were recorded as (playerPos - cameraBlockCorner), so the camera IS
     * the origin and we rotate straight around it.
     */
    private Vector rotateVectorY(Vector v, double angleDeg) {
        double rad = Math.toRadians(angleDeg);
        double cos = Math.cos(rad), sin = Math.sin(rad);
        double rx  = v.getX() * cos - v.getZ() * sin;
        double rz  = v.getX() * sin + v.getZ() * cos;
        return new Vector(rx, v.getY(), rz);
    }

    /**
     * Returns [posRotationCCW, yawOffset] for playback.
     * posRotationCCW: CCW degrees to rotate NPC relative positions = delta_mc
     * yawOffset:      MC yaw degrees to add to recorded yaws         = delta_mc
     */
    private float[] getFacingDeltas(Journal journal, Location playbackLocation) {
        float recordYaw  = journal.getRecordingFacingYaw();
        float playbackYaw;
        try {
            var d = (org.bukkit.block.data.Directional) playbackLocation.getBlock().getBlockData();
            playbackYaw = RecordListener.blockFaceToYaw(d.getFacing());
        } catch (Exception e) {
            playbackYaw = 180f;
        }
        float delta = ((playbackYaw - recordYaw) % 360f + 360f) % 360f;
        return new float[]{delta, delta};
    }

    // ── Viewing actionbar ─────────────────────────────────────────────────────

    private void startViewingActionbar(Player player) {
        UUID id = player.getUniqueId();
        if (viewingActionbarTasks.containsKey(id)) viewingActionbarTasks.get(id).cancel();

        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            String key = viewingJournal.get(id);
            if (key == null || !key.startsWith("VIEWING_")) {
                stopViewingActionbar(player);
                return;
            }
            PlaybackSession sess = activePlaybacks.get(key.substring(8));
            String timeInfo = "";
            if (sess != null) {
                int cur   = sess.currentFrame[0] / 20;
                int total = sess.journal.getFrames().size() / 20;
                timeInfo  = ChatColor.WHITE + "" + cur + "s" + ChatColor.GRAY + "/" + ChatColor.WHITE + "" + total + "s ";
            }
            String msg = ChatColor.AQUA + "● " + ChatColor.YELLOW + "Watching " + timeInfo
                       + ChatColor.GRAY + "(/endjournal to stop)";
            player.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(msg));
        }, 0L, 20L);

        viewingActionbarTasks.put(id, task);
    }

    private void stopViewingActionbar(Player player) {
        BukkitTask t = viewingActionbarTasks.remove(player.getUniqueId());
        if (t != null) t.cancel();
        player.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(""));
    }

    // ── Stop viewing / playback ───────────────────────────────────────────────

    public void stopViewing(Player player) {
        UUID   id      = player.getUniqueId();
        String viewKey = viewingJournal.get(id);
        if (viewKey != null && viewKey.startsWith("VIEWING_")) {
            PlaybackSession sess = activePlaybacks.get(viewKey.substring(8));
            if (sess != null) {
                sess.viewers.remove(id);
                if (sess.viewers.isEmpty()) {
                    sess.playbackTask.cancel();
                    sess.npcs.forEach(NPC::destroy);
                    activePlaybacks.remove(viewKey.substring(8));
                }
            }
        }
        viewingJournal.remove(id);
        stopViewingActionbar(player);
    }

    public boolean isAnyoneViewingAt(Location loc) {
        for (PlaybackSession s : activePlaybacks.values())
            if (s.playbackLocation != null && locationMatches(s.playbackLocation, loc)) return true;
        return false;
    }

    public void stopAllPlaybacks() {
        for (PlaybackSession sess : new ArrayList<>(activePlaybacks.values())) {
            sess.playbackTask.cancel();
            sess.npcs.forEach(NPC::destroy);
            for (UUID vid : sess.viewers) {
                Player v = Bukkit.getPlayer(vid);
                if (v != null && v.isOnline()) {
                    viewingJournal.remove(vid);
                    stopViewingActionbar(v);
                    v.sendMessage(ChatColor.RED + "✗ Video Journal playback stopped by an administrator.");
                }
            }
        }
        activePlaybacks.clear();
    }

    // ── Journal transfer ──────────────────────────────────────────────────────

    private void sendJournalToPlayer(Player recipient, Journal journal, String senderName) {
        plugin.getJournalManager().storeJournal(recipient, journal);
        String journalName = displayName(journal);
        recipient.sendMessage(ChatColor.YELLOW + senderName + " sent you a video journal!");
        recipient.sendMessage(ChatColor.GRAY + "Journal: " + ChatColor.LIGHT_PURPLE + journalName);
        recipient.sendMessage("");
        recipient.sendMessage(ChatColor.AQUA + "Saved to /journals – use it to view!");
    }

    private String displayName(Journal j) {
        return (j.getCustomName() != null && !j.getCustomName().isEmpty()) ? j.getCustomName() : "Unnamed Journal";
    }

    // ── GUI: Journal list ─────────────────────────────────────────────────────

    public void openJournalList(Player player) {
        List<Journal> journals = plugin.getJournalManager().getJournals(player);
        Inventory inv = Bukkit.createInventory(null, 54, TITLE_LIST);

        for (int i = 0; i < Math.min(journals.size(), 54); i++) {
            inv.setItem(i, buildJournalBookItem(journals.get(i), i));
        }
        if (journals.isEmpty()) {
            ItemStack barrier = buildItem(Material.BARRIER,
                ChatColor.RED + "No video journals yet",
                List.of(ChatColor.GRAY + "Use a Video Journal machine to record"));
            inv.setItem(22, barrier);
        }
        player.openInventory(inv);
    }

    // ── GUI: Journal options ──────────────────────────────────────────────────

    public void openJournalOptions(Player player, String journalId) {
        viewingJournal.put(player.getUniqueId(), journalId);
        Journal journal = plugin.getJournalManager().getJournal(player, journalId);
        if (journal == null) { player.sendMessage(ChatColor.RED + "Video journal not found!"); return; }

        Inventory inv = Bukkit.createInventory(null, 54, TITLE_OPTIONS);
        inv.setItem(3, buildItem(Material.GREEN_WOOL,
            ChatColor.GREEN + "" + ChatColor.BOLD + "Keep Journal",
            List.of(ChatColor.GRAY + "Keep and close menu")));
        inv.setItem(5, buildItem(Material.LAVA_BUCKET,
            ChatColor.RED + "" + ChatColor.BOLD + "Delete Journal",
            List.of(ChatColor.GRAY + "Permanently delete this journal", ChatColor.RED + "Cannot be undone!")));

        // Playhead buttons for online players
        int slot = 9;
        for (Player op : Bukkit.getOnlinePlayers()) {
            if (op.equals(player) || slot >= 18) continue;
            inv.setItem(slot++, buildSkullItem(op, ChatColor.AQUA + "Click to send journal"));
        }
        if (player.isOp()) {
            inv.setItem(slot < 18 ? slot : 17, buildItem(Material.NETHER_STAR,
                ChatColor.GOLD + "Broadcast to All",
                List.of(ChatColor.GRAY + "Send to all online players", ChatColor.RED + "Operator only")));
        }
        player.openInventory(inv);
    }

    // ── GUI: Send menu ────────────────────────────────────────────────────────

    public void openSendMenu(Player player, String journalId) {
        Journal journal = plugin.getJournalManager().getJournal(player, journalId);
        if (journal == null) { player.sendMessage(ChatColor.RED + "Video journal not found!"); return; }

        Inventory inv = Bukkit.createInventory(null, 54, TITLE_SEND);
        int slot = 27;
        for (Player op : Bukkit.getOnlinePlayers()) {
            if (op.equals(player) || slot >= 45) continue;
            inv.setItem(slot++, buildSkullItem(op, ChatColor.AQUA + "Click to send journal"));
        }
        if (slot == 27)
            inv.setItem(31, buildItem(Material.BARRIER, ChatColor.RED + "No players online", List.of()));
        if (player.isOp())
            inv.setItem(49, buildItem(Material.NETHER_STAR,
                ChatColor.GOLD + "Send to Everyone",
                List.of(ChatColor.GRAY + "Send to all online players", ChatColor.RED + "Operator only")));
        inv.setItem(45, buildItem(Material.ARROW, ChatColor.YELLOW + "Back", List.of()));

        viewingJournal.put(player.getUniqueId(), journalId);
        player.openInventory(inv);
    }

    // ── GUI: Recording join prompt ────────────────────────────────────────────

    public void openRecordingJoinPrompt(Player player, Location cameraLocation) {
        Inventory inv = Bukkit.createInventory(null, 27, TITLE_JOIN_RECORD);
        inv.setItem(11, buildItem(Material.LIME_CONCRETE,
            ChatColor.GREEN + "" + ChatColor.BOLD + "✓ Join Recording",
            List.of(ChatColor.GRAY + "You will appear in this video journal",
                    ChatColor.GRAY + "Chat visible to participants only")));
        inv.setItem(15, buildItem(Material.RED_CONCRETE,
            ChatColor.RED + "" + ChatColor.BOLD + "✗ Decline",
            List.of(ChatColor.GRAY + "You will not be recorded")));
        player.openInventory(inv);
    }

    // ── GUI: Watch prompt (for nearby players during playback) ────────────────

    public void openWatchPrompt(Player player, Journal journal, Location playbackLocation) {
        Inventory inv = Bukkit.createInventory(null, 27, TITLE_WATCH_PROMPT);
        inv.setItem(11, buildItem(Material.CYAN_CONCRETE,
            ChatColor.AQUA + "" + ChatColor.BOLD + "▶ Watch Journal",
            List.of(ChatColor.GRAY + "From: " + ChatColor.WHITE + journal.getPlayerName(),
                    ChatColor.GRAY + "See the playback and chat messages")));
        inv.setItem(15, buildItem(Material.RED_CONCRETE,
            ChatColor.RED + "" + ChatColor.BOLD + "✗ No Thanks",
            List.of(ChatColor.GRAY + "Continue what you were doing")));

        String watchKey = "WATCH_PROMPT_" + journal.getId() + "_" + System.currentTimeMillis();
        pendingJournals.put(watchKey, journal);
        pendingRecordLocations.put(player.getUniqueId(), playbackLocation);
        viewingJournal.put(player.getUniqueId(), watchKey);
        player.openInventory(inv);
    }

    // ── GUI: Record or Watch? ─────────────────────────────────────────────────

    public void openRecordOrWatchMenu(Player player, Location dispenserLocation) {
        if (plugin.getRecordListener().isRecordingAt(dispenserLocation)) {
            player.sendMessage(ChatColor.RED + "✗ This Video Journal is currently being recorded!");
            return;
        }
        // Check for an active playback at this location – allow joining
        for (Map.Entry<String, PlaybackSession> e : activePlaybacks.entrySet()) {
            PlaybackSession sess = e.getValue();
            if (sess.playbackLocation != null && locationMatches(sess.playbackLocation, dispenserLocation)) {
                if (sess.viewers.size() < MAX_PLAYBACK_VIEWERS) {
                    playVideoJournalAsViewer(player, sess.journal, dispenserLocation);
                    player.sendMessage(ChatColor.GREEN + "✓ Joined ongoing video journal playback!");
                } else {
                    player.sendMessage(ChatColor.RED + "✗ This playback already has " + MAX_PLAYBACK_VIEWERS + " viewers!");
                }
                return;
            }
        }

        Inventory inv = Bukkit.createInventory(null, 27, TITLE_RECORD_WATCH);
        inv.setItem(11, buildItem(Material.RED_CONCRETE,
            ChatColor.RED + "" + ChatColor.BOLD + "● Record",
            List.of(ChatColor.GRAY + "Start recording at this Video Journal",
                    ChatColor.GRAY + "Records players within 10 blocks")));
        inv.setItem(15, buildItem(Material.CYAN_CONCRETE,
            ChatColor.AQUA + "" + ChatColor.BOLD + "▶ Watch",
            List.of(ChatColor.GRAY + "Select a journal from your list to watch")));
        pendingRecordLocations.put(player.getUniqueId(), dispenserLocation);
        player.openInventory(inv);
    }

    // ── GUI: Record confirmation ──────────────────────────────────────────────

    public void openRecordConfirmation(Player player, Location dispenserLocation) {
        if (plugin.getRecordListener().isRecordingAt(dispenserLocation)) {
            player.sendMessage(ChatColor.RED + "✗ This Video Journal is currently being recorded!");
            player.closeInventory();
            return;
        }
        Inventory inv = Bukkit.createInventory(null, 27, TITLE_CONFIRM_RECORD);
        inv.setItem(11, buildItem(Material.LIME_WOOL,
            ChatColor.GREEN + "" + ChatColor.BOLD + "✓ Confirm Recording",
            List.of(ChatColor.GRAY + "Start recording at this Video Journal",
                    ChatColor.GRAY + "Records players within 10 blocks")));
        inv.setItem(15, buildItem(Material.RED_WOOL,
            ChatColor.RED + "" + ChatColor.BOLD + "✗ Cancel", List.of()));
        pendingRecordLocations.put(player.getUniqueId(), dispenserLocation);
        player.openInventory(inv);
    }

    // ── GUI: Journal inventory selection (for watch flow) ─────────────────────

    public void openJournalInventorySelection(Player player) {
        List<Journal> journals = plugin.getJournalManager().getJournals(player);
        Inventory inv = Bukkit.createInventory(null, 54, TITLE_SELECT_WATCH);

        for (int i = 0; i < Math.min(journals.size(), 45); i++) {
            inv.setItem(i, buildJournalBookItem(journals.get(i), i));
        }
        if (journals.isEmpty()) {
            inv.setItem(22, buildItem(Material.BARRIER,
                ChatColor.RED + "No video journals yet",
                List.of(ChatColor.GRAY + "Use a Video Journal machine to create one")));
        }
        player.openInventory(inv);
    }

    // ── GUI: Play confirmation (from physical book item) ──────────────────────

    public void openPlayConfirmation(Player player, Journal journal, String journalKey, ItemStack bookItem) {
        Inventory inv = Bukkit.createInventory(null, 27, TITLE_PLAY_CONFIRM);
        inv.setItem(11, buildItem(Material.GREEN_WOOL,
            ChatColor.GREEN + "✓ Yes, Play Journal",
            List.of(ChatColor.GRAY + "Watch the video journal")));
        inv.setItem(15, buildItem(Material.RED_WOOL,
            ChatColor.RED + "✗ Cancel",
            List.of(ChatColor.GRAY + "Keep the book")));
        viewingJournal.put(player.getUniqueId(), "CONFIRM_" + journalKey);
        player.openInventory(inv);
    }

    // ── Playback engine ───────────────────────────────────────────────────────

    private void playVideoJournal(Player player, Journal journal, Location playbackLocation) {
        if (plugin.getRecordListener().isRecordingAt(playbackLocation)) {
            player.sendMessage(ChatColor.RED + "✗ This Video Journal is currently being recorded!");
            return;
        }
        // Teleport player back to their relative position if known
        Vector rel = plugin.getRecordListener().getPlayerRelativePositions().get(player.getName());
        if (rel != null) player.teleport(playbackLocation.clone().add(rel));

        sendPlaybackHeader(player, journal, -1, journal.getFrames().size() / 20);

        NPCRegistry registry = CitizensAPI.getNPCRegistry();
        List<NPC>        npcs    = new ArrayList<>();
        Map<String, NPC> npcMap  = new HashMap<>();
        Map<UUID, Boolean> askedNearby = new HashMap<>();
        int[] curFrame = {0};

        float[] deltas   = getFacingDeltas(journal, playbackLocation);
        float posRot     = deltas[0];
        float yawOff     = deltas[1];

        String sessionKey = journal.getId() + "_" + System.currentTimeMillis();

        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            PlaybackSession sess = activePlaybacks.get(sessionKey);
            if (sess == null) return;

            List<Journal.JournalFrame> frames = sess.journal.getFrames();
            if (curFrame[0] >= frames.size()) {
                finishSession(sessionKey, sess);
                return;
            }

            // Invite nearby players to join
            for (Player nearby : Bukkit.getOnlinePlayers()) {
                if (nearby.equals(player)) continue;
                if (!nearby.getWorld().equals(playbackLocation.getWorld())) continue;
                if (nearby.getLocation().distance(playbackLocation) > NEARBY_PROMPT_RADIUS) continue;
                if (askedNearby.containsKey(nearby.getUniqueId())) continue;
                if (isViewing(nearby)) continue;
                askedNearby.put(nearby.getUniqueId(), true);
                openWatchPrompt(nearby, journal, playbackLocation);
            }

            tickPlayback(sess, frames.get(curFrame[0]), playbackLocation, npcMap, npcs, posRot, yawOff);
            broadcastChatFrame(frames.get(curFrame[0]), player);
            curFrame[0]++;
        }, 0L, 1L);

        PlaybackSession sess = new PlaybackSession(journal, playbackLocation, npcs, npcMap, curFrame, task);
        sess.viewers.add(player.getUniqueId());
        activePlaybacks.put(sessionKey, sess);
        viewingJournal.put(player.getUniqueId(), "VIEWING_" + sessionKey);
        startViewingActionbar(player);
    }

    private void playVideoJournal(Player player, Journal journal) {
        playVideoJournal(player, journal, journal.getCameraLocation());
    }

    private void playVideoJournalAsViewer(Player player, Journal journal, Location playbackLocation) {
        // Check if there's an existing session at this location
        for (Map.Entry<String, PlaybackSession> e : activePlaybacks.entrySet()) {
            PlaybackSession existing = e.getValue();
            if (existing.playbackLocation != null && locationMatches(existing.playbackLocation, playbackLocation)) {
                existing.viewers.add(player.getUniqueId());
                viewingJournal.put(player.getUniqueId(), "VIEWING_" + e.getKey());
                startViewingActionbar(player);
                sendPlaybackHeader(player, journal,
                    existing.currentFrame[0] / 20, journal.getFrames().size() / 20);
                Vector rel = plugin.getRecordListener().getPlayerRelativePositions().get(player.getName());
                if (rel != null) player.teleport(playbackLocation.clone().add(rel));
                return;
            }
        }
        // No existing session – start a new one for this viewer
        if (journal.getFrames().isEmpty()) {
            player.sendMessage(ChatColor.RED + "This journal has no frames!");
            return;
        }
        sendPlaybackHeader(player, journal, -1, journal.getFrames().size() / 20);
        Vector rel = plugin.getRecordListener().getPlayerRelativePositions().get(player.getName());
        if (rel != null) player.teleport(playbackLocation.clone().add(rel));

        NPCRegistry registry = CitizensAPI.getNPCRegistry();
        List<NPC>        npcs   = new ArrayList<>();
        Map<String, NPC> npcMap = new HashMap<>();
        Map<UUID, Boolean> askedNearby = new HashMap<>();
        int[] curFrame = {0};

        float[] deltas = getFacingDeltas(journal, playbackLocation);
        float posRot   = deltas[0];
        float yawOff   = deltas[1];

        String sessionKey = journal.getId() + "_" + System.currentTimeMillis();
        viewingJournal.put(player.getUniqueId(), "VIEWING_" + sessionKey);
        startViewingActionbar(player);

        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            PlaybackSession sess = activePlaybacks.get(sessionKey);
            if (sess == null) return;

            List<Journal.JournalFrame> frames = sess.journal.getFrames();
            if (curFrame[0] >= frames.size()) {
                finishSession(sessionKey, sess);
                return;
            }

            for (Player nearby : Bukkit.getOnlinePlayers()) {
                if (nearby.equals(player)) continue;
                if (!nearby.getWorld().equals(playbackLocation.getWorld())) continue;
                if (nearby.getLocation().distance(playbackLocation) > NEARBY_PROMPT_RADIUS) continue;
                if (askedNearby.containsKey(nearby.getUniqueId())) continue;
                if (isViewing(nearby)) continue;
                askedNearby.put(nearby.getUniqueId(), true);
                openWatchPrompt(nearby, journal, playbackLocation);
            }

            tickPlayback(sess, frames.get(curFrame[0]), playbackLocation, npcMap, npcs, posRot, yawOff);
            broadcastChatFrame(frames.get(curFrame[0]), player);
            curFrame[0]++;
        }, 0L, 1L);

        PlaybackSession sess = new PlaybackSession(journal, playbackLocation, npcs, npcMap, curFrame, task);
        sess.viewers.add(player.getUniqueId());
        activePlaybacks.put(sessionKey, sess);
    }

    /** Advances one frame: move/create NPCs, apply equipment and motion state. */
    private void tickPlayback(PlaybackSession sess, Journal.JournalFrame frame,
                              Location origin, Map<String, NPC> npcMap,
                              List<NPC> npcList, float posRot, float yawOff) {
        NPCRegistry registry = CitizensAPI.getNPCRegistry();

        // Offset origin to block centre so relative positions land correctly.
        // Block getLocation() returns the corner (integer XZ); players stand at
        // decimal positions, so we add 0.5 on X and Z to match block centre.
        Location centredOrigin = origin.clone().add(0.5, 0, 0.5);

        for (Map.Entry<String, Vector> e : frame.getPlayerRelativePositions().entrySet()) {
            String name    = e.getKey();
            Vector rotated = rotateVectorY(e.getValue(), posRot);
            Float rawYaw   = frame.getPlayerYaw().get(name);
            Float rawPitch = frame.getPlayerPitch().get(name);
            float finalYaw   = rawYaw   != null ? (rawYaw   + yawOff) % 360f : 0f;
            float finalPitch = rawPitch != null ? rawPitch              : 0f;

            Location npcLoc = centredOrigin.clone().add(rotated);
            npcLoc.setYaw(finalYaw);
            npcLoc.setPitch(finalPitch);

            NPC npc = npcMap.get(name);
            if (npc == null) {
                npc = registry.createNPC(EntityType.PLAYER, name);
                npc.getOrAddTrait(SkinTrait.class).setSkinName(name);
                npc.data().set(NPC.Metadata.RESET_YAW_ON_SPAWN, false);
                npc.data().set(NPC.Metadata.RESET_PITCH_ON_TICK, false);
                npc.setUseMinecraftAI(false);
                npc.setProtected(true);
                npc.spawn(npcLoc);
                if (npc.isSpawned()) npc.teleport(npcLoc, TeleportCause.PLUGIN);
                npcList.add(npc);
                npcMap.put(name, npc);
            } else {
                npc.teleport(npcLoc, TeleportCause.PLUGIN);
            }

            if (npc.getEntity() instanceof Player np) {
                Boolean snk = frame.getPlayerSneaking().get(name);
                Boolean spr = frame.getPlayerSprinting().get(name);
                Boolean swm = frame.getPlayerSwimming().get(name);
                if (snk != null) np.setSneaking(snk);
                if (spr != null) np.setSprinting(spr);
                if (swm != null) np.setSwimming(swm);
            }

            // Apply equipment via EquipmentTrait (Citizens manages this per-tick;
            // setting EntityEquipment directly gets overwritten immediately).
            ItemStack[] gear = frame.getPlayerEquipment().get(name);
            if (gear != null && npc.isSpawned()) {
                try {
                    net.citizensnpcs.api.trait.trait.Equipment equipTrait =
                        npc.getOrAddTrait(net.citizensnpcs.api.trait.trait.Equipment.class);
                    // Slots: 0=hand, 1=offhand, 2=boots, 3=legs, 4=chest, 5=helmet
                    // Our gear array: 0=helmet,1=chest,2=legs,3=boots,4=mainhand,5=offhand
                    equipTrait.set(net.citizensnpcs.api.trait.trait.Equipment.EquipmentSlot.HAND,
                        gear[4] != null ? gear[4] : new ItemStack(Material.AIR));
                    equipTrait.set(net.citizensnpcs.api.trait.trait.Equipment.EquipmentSlot.OFF_HAND,
                        gear[5] != null ? gear[5] : new ItemStack(Material.AIR));
                    equipTrait.set(net.citizensnpcs.api.trait.trait.Equipment.EquipmentSlot.BOOTS,
                        gear[3] != null ? gear[3] : new ItemStack(Material.AIR));
                    equipTrait.set(net.citizensnpcs.api.trait.trait.Equipment.EquipmentSlot.LEGGINGS,
                        gear[2] != null ? gear[2] : new ItemStack(Material.AIR));
                    equipTrait.set(net.citizensnpcs.api.trait.trait.Equipment.EquipmentSlot.CHESTPLATE,
                        gear[1] != null ? gear[1] : new ItemStack(Material.AIR));
                    equipTrait.set(net.citizensnpcs.api.trait.trait.Equipment.EquipmentSlot.HELMET,
                        gear[0] != null ? gear[0] : new ItemStack(Material.AIR));
                } catch (Exception ex) {
                    // Fallback to EntityEquipment if EquipmentTrait unavailable
                    if (npc.getEntity() instanceof LivingEntity le) {
                        var eq = le.getEquipment();
                        if (eq != null) {
                            eq.setHelmet(gear[0]);
                            eq.setChestplate(gear[1]);
                            eq.setLeggings(gear[2]);
                            eq.setBoots(gear[3]);
                            eq.setItemInMainHand(gear[4] != null ? gear[4] : new ItemStack(Material.AIR));
                            eq.setItemInOffHand(gear[5]  != null ? gear[5] : new ItemStack(Material.AIR));
                        }
                    }
                }
            }
        }

        // Destroy NPCs that are no longer in this frame
        Set<String> nowInFrame = frame.getPlayerRelativePositions().keySet();
        List<String> remove = new ArrayList<>();
        for (String n : npcMap.keySet()) {
            if (!nowInFrame.contains(n)) { npcMap.get(n).destroy(); npcList.remove(npcMap.get(n)); remove.add(n); }
        }
        remove.forEach(npcMap::remove);
    }

    /** Broadcasts a chat message frame to all current session viewers. */
    private void broadcastChatFrame(Journal.JournalFrame frame, Player initiator) {
        String chatMsg    = frame.getChatMessage();
        String chatSender = frame.getChatSender();
        if (chatMsg == null || chatMsg.isEmpty() || chatSender == null) return;

        String formatted = ChatColor.GRAY + "[" + ChatColor.LIGHT_PURPLE + "Journal"
                         + ChatColor.GRAY + "] " + ChatColor.YELLOW + chatSender
                         + ChatColor.GRAY + ": " + ChatColor.WHITE + chatMsg;
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (isViewing(p)) p.sendMessage(formatted);
        }
    }

    /** Cleans up a finished playback session and notifies all viewers. */
    private void finishSession(String sessionKey, PlaybackSession sess) {
        String sep = ChatColor.STRIKETHROUGH + "" + ChatColor.DARK_GRAY + "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━";
        for (UUID vid : new HashSet<>(sess.viewers)) {
            Player v = Bukkit.getPlayer(vid);
            if (v != null && v.isOnline()) {
                v.sendMessage(sep);
                v.sendMessage(ChatColor.GREEN + "✓ Video journal playback finished.");
                plugin.getRecordListener().sendChatRecap(v, sess.journal);
                viewingJournal.remove(vid);
                stopViewingActionbar(v);
            }
        }
        sess.npcs.forEach(NPC::destroy);
        sess.playbackTask.cancel();
        activePlaybacks.remove(sessionKey);
    }

    // ── Item builders ─────────────────────────────────────────────────────────

    private ItemStack buildItem(Material mat, String name, List<String> lore) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta  = item.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack buildSkullItem(Player target, String loreText) {
        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta  = (SkullMeta) skull.getItemMeta();
        meta.setOwningPlayer(target);
        meta.setDisplayName(ChatColor.GREEN + target.getName());
        meta.setLore(List.of(loreText));
        skull.setItemMeta(meta);
        return skull;
    }

    private ItemStack buildJournalBookItem(Journal journal, int index) {
        ItemStack item = new ItemStack(Material.WRITTEN_BOOK);
        ItemMeta meta  = item.getItemMeta();
        String displayName = (journal.getCustomName() != null && !journal.getCustomName().isEmpty())
            ? ChatColor.LIGHT_PURPLE + "🎬 " + journal.getCustomName()
            : ChatColor.LIGHT_PURPLE + "🎬 Recording #" + (index + 1);
        meta.setDisplayName(displayName);
        Location cam = journal.getCameraLocation();
        meta.setLore(List.of(
            ChatColor.GRAY + "Owner: "    + ChatColor.WHITE + journal.getPlayerName(),
            ChatColor.GRAY + "Date: "     + ChatColor.WHITE + journal.getTimestamp(),
            ChatColor.GRAY + "Duration: " + ChatColor.WHITE + (journal.getFrames().size() / 20) + "s",
            ChatColor.GRAY + "Camera: "   + ChatColor.WHITE + cam.getBlockX() + ", " + cam.getBlockY() + ", " + cam.getBlockZ(),
            "",
            ChatColor.YELLOW + "Click to view options"
        ));
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack buildJournalBook(Journal journal, String senderName) {
        ItemStack book = new ItemStack(Material.WRITTEN_BOOK);
        ItemMeta meta  = book.getItemMeta();
        meta.setDisplayName(ChatColor.LIGHT_PURPLE + displayName(journal));
        meta.setLore(List.of(
            ChatColor.GRAY + "From: " + ChatColor.WHITE + senderName,
            ChatColor.GRAY + "Date: " + ChatColor.WHITE + journal.getTimestamp(),
            "",
            ChatColor.YELLOW + "Right-click a Video Journal machine to watch"
        ));
        book.setItemMeta(meta);
        return book;
    }

    private void sendPlaybackHeader(Player player, Journal journal, int currentSec, int totalSec) {
        player.sendMessage("");
        player.sendMessage(ChatColor.GOLD + "━━━━━━━━ Video Journal ━━━━━━━━");
        player.sendMessage(ChatColor.GRAY + "From: " + ChatColor.WHITE + journal.getPlayerName());
        player.sendMessage(ChatColor.GRAY + "Date: " + ChatColor.WHITE + journal.getTimestamp());
        if (currentSec >= 0)
            player.sendMessage(ChatColor.YELLOW + "Joined at " + currentSec + "s/" + totalSec + "s");
        player.sendMessage(ChatColor.GOLD + "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        player.sendMessage(ChatColor.STRIKETHROUGH + "" + ChatColor.DARK_GRAY + "━━━━━━━━ WATCHING ━━━━━━━━");
    }

    // ── Chat event (journal naming) ───────────────────────────────────────────

    @EventHandler
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        Player player   = event.getPlayer();
        UUID   playerId = player.getUniqueId();

        if (awaitingJournalName.containsKey(playerId)) {
            event.setCancelled(true);
            String journalId  = awaitingJournalName.remove(playerId);
            String customName = event.getMessage();
            Journal journal = plugin.getJournalManager().getJournal(player, journalId);
            if (journal != null) {
                journal.setCustomName(customName);
                plugin.getJournalManager().updateJournal(player, journal);
                player.sendMessage(ChatColor.GREEN + "✓ Video journal named: " + ChatColor.LIGHT_PURPLE + customName);
                Bukkit.getScheduler().runTask(plugin, () -> openJournalOptions(player, journalId));
            } else {
                player.sendMessage(ChatColor.RED + "✗ Failed to name journal!");
            }
            return;
        }

        // Suppress chat for viewers and from viewers to non-viewers
        if (viewingJournal.containsKey(playerId) && viewingJournal.get(playerId).startsWith("VIEWING_"))
            event.getRecipients().remove(player);

        event.getRecipients().removeIf(r ->
            viewingJournal.containsKey(r.getUniqueId())
            && viewingJournal.get(r.getUniqueId()).startsWith("VIEWING_"));
    }

    // ── Inventory events ──────────────────────────────────────────────────────

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        String t = event.getView().getTitle();
        if (t.contains("Journal") || t.contains("Record") || t.contains("Watch")
                || t.contains("Send")   || t.contains("Everyone"))
            event.setCancelled(true);
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        if (event.getView().getTitle().equals(TITLE_OPTIONS)) {
            String jid = viewingJournal.remove(player.getUniqueId());
            if (jid != null) player.sendMessage(ChatColor.GREEN + "✓ Video journal kept.");
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        String title = event.getView().getTitle();
        ItemStack clicked = event.getCurrentItem();

        // ── Watch prompt ──────────────────────────────────────────────────────
        if (title.equals(TITLE_WATCH_PROMPT)) {
            event.setCancelled(true);
            if (clicked == null || clicked.getType() == Material.AIR) return;
            String key = viewingJournal.get(player.getUniqueId());
            if (clicked.getType() == Material.CYAN_CONCRETE) {
                Journal j   = pendingJournals.remove(key);
                Location loc = pendingRecordLocations.remove(player.getUniqueId());
                if (j != null && loc != null) { player.closeInventory(); playVideoJournalAsViewer(player, j, loc); }
            } else if (clicked.getType() == Material.RED_CONCRETE) {
                pendingJournals.remove(key);
                pendingRecordLocations.remove(player.getUniqueId());
                viewingJournal.remove(player.getUniqueId());
                player.closeInventory();
                player.sendMessage(ChatColor.GRAY + "You declined to watch the journal.");
            }
            return;
        }

        // ── Join recording ────────────────────────────────────────────────────
        if (title.equals(TITLE_JOIN_RECORD)) {
            event.setCancelled(true);
            if (clicked == null || clicked.getType() == Material.AIR) return;
            if (clicked.getType() == Material.LIME_CONCRETE) {
                plugin.getRecordListener().addParticipatingPlayer(player.getUniqueId());
                player.closeInventory();
                player.sendMessage(ChatColor.GREEN + "✓ You joined the recording!");
                player.sendMessage(ChatColor.STRIKETHROUGH + "" + ChatColor.DARK_GRAY + "━━━━━━━━ RECORDING ━━━━━━━━");
            } else if (clicked.getType() == Material.RED_CONCRETE) {
                player.closeInventory();
                player.sendMessage(ChatColor.GRAY + "You declined to join the recording.");
            }
            return;
        }

        // ── Record or Watch ───────────────────────────────────────────────────
        if (title.equals(TITLE_RECORD_WATCH)) {
            event.setCancelled(true);
            if (clicked == null || clicked.getType() == Material.AIR) return;
            Location loc = pendingRecordLocations.get(player.getUniqueId());
            if (clicked.getType() == Material.RED_CONCRETE) {
                player.closeInventory();
                if (loc != null) openRecordConfirmation(player, loc);
            } else if (clicked.getType() == Material.CYAN_CONCRETE) {
                player.closeInventory();
                openJournalInventorySelection(player);
            }
            return;
        }

        // ── Confirm record ────────────────────────────────────────────────────
        if (title.equals(TITLE_CONFIRM_RECORD)) {
            event.setCancelled(true);
            if (clicked == null || clicked.getType() == Material.AIR) return;
            if (clicked.getType() == Material.LIME_WOOL) {
                Location loc = pendingRecordLocations.remove(player.getUniqueId());
                if (loc != null) { player.closeInventory(); plugin.getRecordListener().startRecording(player, loc); }
            } else if (clicked.getType() == Material.RED_WOOL) {
                pendingRecordLocations.remove(player.getUniqueId());
                player.closeInventory();
                player.sendMessage(ChatColor.GRAY + "Recording cancelled.");
            }
            return;
        }

        // ── Select journal to watch ───────────────────────────────────────────
        if (title.equals(TITLE_SELECT_WATCH)) {
            event.setCancelled(true);
            if (clicked == null || clicked.getType() != Material.WRITTEN_BOOK) return;
            List<Journal> journals = plugin.getJournalManager().getJournals(player);
            int slot = event.getSlot();
            if (slot < journals.size()) {
                Journal j    = journals.get(slot);
                Location loc = pendingRecordLocations.getOrDefault(player.getUniqueId(), j.getCameraLocation());
                player.closeInventory();
                playVideoJournal(player, j, loc);
            }
            return;
        }

        // ── Play confirmation (book item flow) ────────────────────────────────
        if (title.equals(TITLE_PLAY_CONFIRM)) {
            event.setCancelled(true);
            if (clicked == null || clicked.getType() == Material.AIR) return;
            String state = viewingJournal.get(player.getUniqueId());
            if (state == null || !state.startsWith("CONFIRM_")) { player.closeInventory(); return; }
            String journalKey = state.substring(8);
            Journal j = pendingJournals.get(journalKey);
            if (j == null) { player.closeInventory(); player.sendMessage(ChatColor.RED + "Journal not found!"); viewingJournal.remove(player.getUniqueId()); return; }
            if (clicked.getType() == Material.GREEN_WOOL) {
                // Remove the physical book
                for (ItemStack item : player.getInventory().getContents()) {
                    if (item == null || item.getType() != Material.WRITTEN_BOOK) continue;
                    ItemMeta m = item.getItemMeta();
                    if (m == null || !m.hasLore()) continue;
                    for (String line : m.getLore()) {
                        if (ChatColor.stripColor(line).equals(journalKey)) { item.setAmount(0); break; }
                    }
                }
                pendingJournals.remove(journalKey);
                viewingJournal.remove(player.getUniqueId());
                player.closeInventory();
                playVideoJournal(player, j);
            } else if (clicked.getType() == Material.RED_WOOL) {
                viewingJournal.remove(player.getUniqueId());
                player.closeInventory();
                player.sendMessage(ChatColor.GRAY + "Cancelled. You can play it later.");
            }
            return;
        }

        // ── Journal list ──────────────────────────────────────────────────────
        if (title.equals(TITLE_LIST)) {
            event.setCancelled(true);
            if (clicked == null || clicked.getType() != Material.WRITTEN_BOOK) return;
            List<Journal> journals = plugin.getJournalManager().getJournals(player);
            int slot = event.getSlot();
            if (slot >= 0 && slot < journals.size()) {
                player.closeInventory();
                openJournalOptions(player, journals.get(slot).getId());
            }
            return;
        }

        // ── Journal options ───────────────────────────────────────────────────
        if (title.equals(TITLE_OPTIONS)) {
            event.setCancelled(true);
            if (clicked == null || clicked.getType() == Material.AIR) return;
            String journalId = viewingJournal.get(player.getUniqueId());
            if (journalId == null) { player.closeInventory(); return; }
            Journal j = plugin.getJournalManager().getJournal(player, journalId);
            if (j == null) { player.sendMessage(ChatColor.RED + "Journal not found!"); player.closeInventory(); return; }

            if (clicked.getType() == Material.GREEN_WOOL) {
                player.closeInventory();
                player.sendMessage(ChatColor.GREEN + "✓ Video journal kept.");
                viewingJournal.remove(player.getUniqueId());
            } else if (clicked.getType() == Material.LAVA_BUCKET) {
                plugin.getJournalManager().deleteJournal(player, journalId);
                player.closeInventory();
                player.sendMessage(ChatColor.RED + "✗ Video journal deleted.");
                viewingJournal.remove(player.getUniqueId());
            } else if (clicked.getType() == Material.PLAYER_HEAD) {
                SkullMeta meta = (SkullMeta) clicked.getItemMeta();
                if (meta == null || !meta.hasDisplayName()) return;
                String targetName = ChatColor.stripColor(meta.getDisplayName());
                Player target = Bukkit.getPlayerExact(targetName);
                if (target != null && target.isOnline()) {
                    sendJournalToPlayer(target, j, player.getName());
                    player.closeInventory();
                    player.sendMessage(ChatColor.GREEN + "✓ Sent " + ChatColor.LIGHT_PURPLE + displayName(j)
                        + ChatColor.GREEN + " to " + target.getName() + "!");
                    viewingJournal.remove(player.getUniqueId());
                } else {
                    player.sendMessage(ChatColor.RED + "✗ Player is no longer online!");
                    player.closeInventory();
                }
            } else if (clicked.getType() == Material.NETHER_STAR) {
                if (!player.isOp()) { player.sendMessage(ChatColor.RED + "✗ Operators only!"); player.closeInventory(); return; }
                int count = 0;
                for (Player op : Bukkit.getOnlinePlayers()) {
                    if (!op.equals(player)) { sendJournalToPlayer(op, j, player.getName()); count++; }
                }
                player.closeInventory();
                player.sendMessage(count > 0
                    ? ChatColor.GREEN + "✓ Sent " + ChatColor.LIGHT_PURPLE + displayName(j) + ChatColor.GREEN + " to " + count + " player(s)!"
                    : ChatColor.RED + "✗ No other players online!");
                viewingJournal.remove(player.getUniqueId());
            }
            return;
        }

        // ── Send to player menu ───────────────────────────────────────────────
        if (title.equals(TITLE_SEND)) {
            event.setCancelled(true);
            if (clicked == null || clicked.getType() == Material.AIR) return;
            String journalId = viewingJournal.get(player.getUniqueId());
            if (journalId == null) { player.closeInventory(); return; }
            Journal j = plugin.getJournalManager().getJournal(player, journalId);
            if (j == null) { player.closeInventory(); player.sendMessage(ChatColor.RED + "Journal not found!"); return; }

            if (clicked.getType() == Material.PLAYER_HEAD) {
                SkullMeta meta = (SkullMeta) clicked.getItemMeta();
                if (meta == null || !meta.hasDisplayName()) return;
                String targetName = ChatColor.stripColor(meta.getDisplayName());
                Player target = Bukkit.getPlayerExact(targetName);
                if (target != null && target.isOnline()) {
                    sendJournalToPlayer(target, j, player.getName());
                    player.closeInventory();
                    player.sendMessage(ChatColor.GREEN + "✓ Sent " + ChatColor.LIGHT_PURPLE + displayName(j)
                        + ChatColor.GREEN + " to " + target.getName() + "!");
                    viewingJournal.remove(player.getUniqueId());
                } else {
                    player.sendMessage(ChatColor.RED + "✗ Player is no longer online!");
                    player.closeInventory();
                }
            } else if (clicked.getType() == Material.NETHER_STAR) {
                if (!player.isOp()) { player.sendMessage(ChatColor.RED + "✗ Operators only!"); player.closeInventory(); return; }
                int count = 0;
                for (Player op : Bukkit.getOnlinePlayers()) {
                    if (!op.equals(player)) { sendJournalToPlayer(op, j, player.getName()); count++; }
                }
                player.closeInventory();
                player.sendMessage(count > 0
                    ? ChatColor.GREEN + "✓ Sent to " + count + " player(s)!"
                    : ChatColor.RED + "✗ No other players online!");
                viewingJournal.remove(player.getUniqueId());
            } else if (clicked.getType() == Material.ARROW) {
                player.closeInventory();
                openJournalList(player);
                viewingJournal.remove(player.getUniqueId());
            }
        }
    }

    // ── PlaybackSession inner class ───────────────────────────────────────────

    private static class PlaybackSession {
        final Journal          journal;
        final Location         playbackLocation;
        final List<NPC>        npcs;
        final Map<String, NPC> npcMap;
        final int[]            currentFrame;
        final BukkitTask       playbackTask;
        final Set<UUID>        viewers = new HashSet<>();

        PlaybackSession(Journal journal, Location playbackLocation,
                        List<NPC> npcs, Map<String, NPC> npcMap,
                        int[] currentFrame, BukkitTask playbackTask) {
            this.journal         = journal;
            this.playbackLocation= playbackLocation;
            this.npcs            = npcs;
            this.npcMap          = npcMap;
            this.currentFrame    = currentFrame;
            this.playbackTask    = playbackTask;
        }
    }
}
