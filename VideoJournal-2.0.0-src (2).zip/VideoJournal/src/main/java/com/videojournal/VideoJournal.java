package com.videojournal;

import org.bukkit.plugin.java.JavaPlugin;

public class VideoJournal extends JavaPlugin {

    private JournalManager journalManager;
    private RecordListener recordListener;
    private JournalGUI journalGUI;
    private DispenserListener dispenserListener;
    private boolean journalsEnabled = true;

    @Override
    public void onEnable() {
        if (getServer().getPluginManager().getPlugin("Citizens") == null) {
            getLogger().severe("Citizens not found! VideoJournal requires Citizens.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        journalManager    = new JournalManager(this);
        recordListener    = new RecordListener(this);
        journalGUI        = new JournalGUI(this);
        dispenserListener = new DispenserListener(this);

        getServer().getPluginManager().registerEvents(recordListener, this);
        getServer().getPluginManager().registerEvents(journalGUI, this);
        getServer().getPluginManager().registerEvents(dispenserListener, this);

        getCommand("journals").setExecutor(new JournalsCommand(this));
        getCommand("endjournal").setExecutor(new EndJournalCommand(this));
        getCommand("disablejournals").setExecutor(new ToggleJournalsCommand(this, false));
        getCommand("enablejournals").setExecutor(new ToggleJournalsCommand(this, true));

        getLogger().info("VideoJournal v2.0.0 enabled.");
    }

    @Override
    public void onDisable() {
        if (recordListener != null) recordListener.cancelRecording();
        if (journalGUI    != null) journalGUI.stopAllPlaybacks();
        getLogger().info("VideoJournal disabled.");
    }

    public JournalManager getJournalManager()   { return journalManager; }
    public RecordListener getRecordListener()   { return recordListener; }
    public JournalGUI     getJournalGUI()        { return journalGUI; }
    public boolean        isJournalsEnabled()    { return journalsEnabled; }
    public void           setJournalsEnabled(boolean v) { journalsEnabled = v; }
}
