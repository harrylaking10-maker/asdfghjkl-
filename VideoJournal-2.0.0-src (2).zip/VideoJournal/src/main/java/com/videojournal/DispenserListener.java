package com.videojournal;

import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

/**
 * Handles right-click interactions on Dispensers (and their partner Lecterns).
 *
 * A "Video Journal machine" is a Dispenser placed directly above a Lectern.
 * Right-clicking either block opens the record/watch interface.
 *
 * If the player is holding a Written Book that was issued as a journal,
 * a play-confirmation menu is shown instead.
 */
public class DispenserListener implements Listener {

    private final VideoJournal plugin;

    public DispenserListener(VideoJournal plugin) {
        this.plugin = plugin;
    }

    // ── Dispenser click ───────────────────────────────────────────────────────

    @EventHandler
    public void onDispenserClick(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Block clicked = event.getClickedBlock();
        if (clicked == null || clicked.getType() != Material.DISPENSER) return;

        Player player = event.getPlayer();

        if (!plugin.isJournalsEnabled()) {
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "✗ Video Journals are currently disabled.");
            return;
        }
        if (!player.hasPermission("permission.videojournal")) {
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "✗ You do not have permission to use Video Journals!");
            return;
        }

        // Must have a Lectern directly below
        if (clicked.getRelative(0, -1, 0).getType() != Material.LECTERN) {
            event.setCancelled(true);
            return;
        }

        event.setCancelled(true);
        Location dispenserLoc = clicked.getLocation();

        // Check if player is holding a journal book
        ItemStack held = player.getInventory().getItemInMainHand();
        if (held.getType() == Material.WRITTEN_BOOK && held.hasItemMeta()) {
            ItemMeta meta = held.getItemMeta();
            if (meta.hasLore()) {
                for (String line : meta.getLore()) {
                    String stripped = ChatColor.stripColor(line);
                    if (stripped.startsWith("journal_") && plugin.getJournalGUI().hasPendingJournal(stripped)) {
                        plugin.getJournalGUI().openPlayConfirmation(
                            player,
                            plugin.getJournalGUI().getPendingJournal(stripped),
                            stripped,
                            held);
                        return;
                    }
                }
            }
        }

        plugin.getJournalGUI().openRecordOrWatchMenu(player, dispenserLoc);
    }

    // ── Lectern click ─────────────────────────────────────────────────────────

    @EventHandler
    public void onLecternClick(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Block clicked = event.getClickedBlock();
        if (clicked == null || clicked.getType() != Material.LECTERN) return;

        Player player = event.getPlayer();

        if (!plugin.isJournalsEnabled()) {
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "✗ Video Journals are currently disabled.");
            return;
        }
        if (!player.hasPermission("permission.videojournal")) {
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "✗ You do not have permission to use Video Journals!");
            return;
        }

        // Only act if there is a Dispenser directly above
        Block above = clicked.getRelative(0, 1, 0);
        if (above.getType() != Material.DISPENSER) return;

        event.setCancelled(true);
        plugin.getJournalGUI().openRecordOrWatchMenu(player, above.getLocation());
    }
}
